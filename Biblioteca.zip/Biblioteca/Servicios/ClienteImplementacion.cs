﻿using Biblioteca.Dtos;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteca.Servicios
{
    internal class ClienteImplementacion : ClienteInterfaz
    {
        public void validarAltaCliente()
        {
            Console.WriteLine("Introduzca el id de la biblioteca en la cual desea dar de alta al cliente");
            Utilidades.util.mostrarListaBibliotecas();
            long idBibliotecaSeleccionado = Convert.ToInt64(Console.ReadLine());
            foreach (BibliotecasDto biblio in Program.listaBiblioteca)
            {
                if (biblio.IdBiblioteca == idBibliotecaSeleccionado)
                {
                    darAltaCliente();
                }
                else
                {
                    Console.WriteLine("La biblioteca seleccionada no existe, introduzca un id valido");
                }
            }

        }


        private void darAltaCliente()
        {
            Console.WriteLine("-----------------");
            Console.WriteLine("DAR ALTA CLIENTE");
            Console.WriteLine("------------------------");
            long idU = Utilidades.util.calcularIdCliente();
            Console.WriteLine("Introduzca el nombre del usuario");
            string usuario = Console.ReadLine();
            Console.WriteLine("Introduzca primer apellido ");
            string apellido = Console.ReadLine();
            Console.WriteLine("Introduzca segundo apellido");
            string apellidoSegundo= Console.ReadLine();
            Console.WriteLine("Introduzca su fecha de nacimiento ");
            string fecha = Console.ReadLine();
            Console.WriteLine("Introduzca el DNI del usuario");
            string dni= Console.ReadLine();
            Console.WriteLine("Introduzca el email del usuario");
            string email= Console.ReadLine();
            ClientesDto cliente = new ClientesDto();
            Program.listaClientes.Add(cliente);
        }
    }
}
