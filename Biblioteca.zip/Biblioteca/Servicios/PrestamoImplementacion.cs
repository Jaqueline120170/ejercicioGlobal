﻿using Biblioteca.Dtos;
using Biblioteca.Utilidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteca.Servicios
{
    internal class PrestamoImplementacion : PrestamoInterfaz
    {
        public void validarAltaPrestamo()
        {
            try
            {
                Console.WriteLine("Introduzca el id de la biblioteca en la cual desea realizar el prestamo");
                Utilidades.util.mostrarListaBibliotecas();
                long idBibliotecaSeleccionado = Convert.ToInt64(Console.ReadLine());
                foreach (BibliotecasDto biblio in Program.listaBiblioteca)
                {
                    if (biblio.IdBiblioteca.Equals(idBibliotecaSeleccionado))
                    {
                        Console.WriteLine("Introduzca el id del cliente");
                        Utilidades.util.mostrarListaClientes();
                        long id = Convert.ToInt64(Console.ReadLine());
                        foreach (ClientesDto cliente in Program.listaClientes)
                        {
                            if (cliente.IdCliente.Equals(id))
                            {
                                foreach(LibrosDto libros in Program.listaLibros)
                                {
                                    if (libros.StockLibros > 0)
                                    {
                                        bool suficientesLibros = true;
                                        if (suficientesLibros)
                                        {
                                            validarAltaPrestamo();
                                        }
                                    }
                                    else
                                    {
                                        Console.WriteLine("No hay suficientes libros disponibles para gestionar un prestamo en esta biblioteca.");
                                    }
                                }
                               
                                
                            }
                            else
                            {
                                Console.WriteLine("El cliente no existe");
                            }
                        }
                    }
                    else
                    {
                        Console.WriteLine("La biblioteca seleccionada no existe, introduzca un id valido");
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        private void darAltaPrestamo()
        {
            try
            {
                long idP = Utilidades.util.calcularIdPrestamo();
                Console.WriteLine("ID prestamo: " + idP);


                DateTime fechaPrestamo = DateTime.Today.AddDays(1);
                Console.WriteLine("Fecha prestamo" + fechaPrestamo);

                DateTime fechaFinPrestamo = fechaPrestamo.AddDays(7);
                Console.WriteLine("Fecha fin prestamo:" + fechaFinPrestamo);

                Console.WriteLine("Introduce el estado del prestamo");
                string Estado = Console.ReadLine();

                PrestamosDto prestamo = new PrestamosDto(idP, fechaPrestamo, fechaFinPrestamo, Estado);

                Program.listaPrestamos.Add(prestamo);
            }
            catch (Exception ex)
            {
                throw;
            }

        }
    }
}
         


