﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteca.Dtos
{
    internal class ClientesDto
    {
        //Propiedades de la clase clientedto 
        long idCliente;
        string nombreCliente = "aaaaa";
        string apellido1 = "aaaaa";
        string apellido2 = "aaaaa";
        string fechaNac = "12/12/1999";
        string dniCliente = "aaaaa";
        string emailCliente = "aaaaa";
        DateTime fechaInicioSuspencion= DateTime.Now;
        DateTime fechaFinSuspension = DateTime.Now;

        //Constructor vacío
        public ClientesDto()
        {
        }

        //constructor  de referencia para obtener los datos que requiere cada objeto cliente y añadir a la lista
        public ClientesDto(long idCliente, string nombreCliente, string apellido1, string apellido2, string fechaNac, string dniCliente, string emailCliente, DateTime fechaInicioSuspencion, DateTime fechaFinSuspension)
        {
            this.idCliente = idCliente;
            this.nombreCliente = nombreCliente;
            this.apellido1 = apellido1;
            this.apellido2 = apellido2;
            this.fechaNac = fechaNac;
            this.dniCliente = dniCliente;
            this.emailCliente = emailCliente;
            this.fechaInicioSuspencion = fechaInicioSuspencion;
            this.fechaFinSuspension = fechaFinSuspension;
        }



        //Métodos de acceso getters y setters
        public long IdCliente { get => idCliente; set => idCliente = value; }
        public string NombreCliente { get => nombreCliente; set => nombreCliente = value; }
        public string Apellido1 { get => apellido1; set => apellido1 = value; }
        public string Apellido2 { get => apellido2; set => apellido2 = value; }
        public string FechaNac { get => fechaNac; set => fechaNac = value; }
        public string DniCliente { get => dniCliente; set => dniCliente = value; }
        public string EmailCliente { get => emailCliente; set => emailCliente = value; }
        public DateTime FechaInicioSuspencion { get => fechaInicioSuspencion; set => fechaInicioSuspencion = value; }
        public DateTime FechaFinSuspension { get => fechaFinSuspension; set => fechaFinSuspension = value; }

        override
        public string ToString()
        {
            string clienteString = "Lista de Clientes\n" + this.idCliente + " " + this.nombreCliente;
            return clienteString;
        }
    }
}
