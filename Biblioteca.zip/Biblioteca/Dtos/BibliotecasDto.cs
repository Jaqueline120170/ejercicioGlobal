﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Biblioteca.Dtos
{
    internal class BibliotecasDto

    {
        ///Propiedades del objeto bibliotecasdto
        long idBiblioteca;
        string nombreBiblioteca = "aaaaa";
        string direccionBiblioteca = "aaaaa";

        ///contructor vacío
        public BibliotecasDto()
        {
        }



        ///contructor de referencia para dar de alta una nueva biblioteca
        public BibliotecasDto(long idBiblioteca, string nombreBiblioteca, string direccionBiblioteca)
        {
            this.idBiblioteca = idBiblioteca;
            this.nombreBiblioteca = nombreBiblioteca;
            this.direccionBiblioteca = direccionBiblioteca;
        }

        //Métodos de acceso getters y setters
        public long IdBiblioteca { get => idBiblioteca; set => idBiblioteca = value; }
        public string NombreBiblioteca { get => nombreBiblioteca; set => nombreBiblioteca = value; }
        public string DireccionBiblioteca { get => direccionBiblioteca; set => direccionBiblioteca = value; }

        override
         public string ToString()
        {
            string bibliotecaString = "Lista de bibliotecas\n" + this.idBiblioteca + " " + this.nombreBiblioteca;
            return bibliotecaString;
        }



    }

 
  
}
