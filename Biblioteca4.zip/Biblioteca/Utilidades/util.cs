﻿using Biblioteca.Dtos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteca.Utilidades
{
    internal class util
    {
       public static void mostrarListaBibliotecas()
        {
           
            foreach (BibliotecasDto biblioteca in Program.listaBiblioteca)
            {
                Console.WriteLine(biblioteca.ToString());
            }
        }
        public static void mostrarListaClientes()
        {
            
            foreach (ClientesDto clientes in Program.listaClientes)
            {
                Console.WriteLine(clientes.ToString());
            }
        }
        public static long calcularIdBiblioteca()
        {

            long nuevoId = 0;
            int tamanio = Program.listaBiblioteca.Count;

            if (tamanio > 0)
            {

                nuevoId = Program.listaBiblioteca[tamanio - 1].IdBiblioteca + 1;

            }
            else
            {

                nuevoId = 1;

            }

            return nuevoId;

        }

        public static long calcularIdCliente()
        {

            long idC = 0;
            int tamanio = Program.listaClientes.Count;

            if (tamanio > 0)
            {

                idC = Program.listaClientes[tamanio - 1].IdCliente + 1;

            }
            else
            {

                idC = 1;

            }

            return idC;

        }
        public static long calcularIdLibro()
        {

            long idL = 0;
            int tamanio = Program.listaLibros.Count;

            if (tamanio > 0)
            {

                idL = Program.listaLibros[tamanio - 1].IdLibro + 1;

            }
            else
            {

                idL= 1;

            }

            return idL;

        }

        public static long calcularIdPrestamo()
        {

            long idP = 0;
            int tamanio = Program.listaPrestamos.Count;

            if (tamanio > 0)
            {

                idP= Program.listaPrestamos[tamanio - 1].IdPrestamo + 1;

            }
            else
            {

                idP = 1;

            }

            return idP;

        }
    }
}
