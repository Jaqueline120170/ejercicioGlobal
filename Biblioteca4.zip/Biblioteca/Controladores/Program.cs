﻿using Biblioteca.Dtos;
using Biblioteca.Servicios;
using System.Security.Cryptography.X509Certificates;

namespace Biblioteca
{
    class Program
    {
        public static List<BibliotecasDto> listaBiblioteca = new List<BibliotecasDto>();
        public static List<ClientesDto> listaClientes = new List<ClientesDto>();
        public static List<LibrosDto> listaLibros = new List<LibrosDto>();
        public static List<PrestamosDto> listaPrestamos = new List<PrestamosDto>();

        /// <summary>
        /// Método principal d ela aplicación
        /// </summary>
        /// <param name="args"></param>
        public static void Main(string[] args)
        {
            ///Constructores de clases e interfaces
            MenuInterfaz mi = new MenuImplementacion();
            BibliotecaInterfaz bi = new BibliotecaImplementacion();


            try
            {
                //variables de flujo
                int opcionPrincipal;
                bool cerrarMenu = false;

                //Creacion de ficheros
                string fecha = DateTime.Today.ToString("ddMMyyyy");
                string rutaFicheroGeneral = "C:\\Users\\Usuario\\source\\repos\\Biblioteca\\" + fecha + ".txt";
                string rutaFicheroClientes = "C:\\Users\\Usuario\\source\\repos\\Biblioteca\\rutaFicheroClientes" + fecha + ".txt";
                string rutaFicheroLibros = "C:\\Users\\Usuario\\source\\repos\\Biblioteca\\" + fecha + ".txt";
                string rutaFicheroPrestamos = "C:\\Users\\Usuario\\source\\repos\\Biblioteca\\" + fecha + ".txt";

                // METODOS ESTATICOS QUE MUESTRAN EL ESTADO ACTUAL DE LOS FICHEROS AL MOMENTO DE ABRIR LA APP Y EL CONTENIDO
                Utilidades.GestorFicherosImplementacion.accesoAFicheros(rutaFicheroGeneral);
                Utilidades.GestorFicherosImplementacion.guardarClienteBDD(rutaFicheroClientes);
                //Utilidades.GestorFicherosImplementacion.mostrarContenidoFicheros(rutaFicheroGeneral);

                while (!cerrarMenu)
                {
                    int opcion = mi.mostrarMenuPrincipal();
                    switch (opcion)
                    {
                        case 0:
                            using (StreamWriter sw = new StreamWriter(rutaFicheroGeneral))
                            {
                                foreach(BibliotecasDto biblioteca in listaBiblioteca)
                                {
          
                                    sw.WriteLine(biblioteca.IdBiblioteca + ";" + biblioteca.NombreBiblioteca
                                        + ";" + biblioteca.DireccionBiblioteca);
                                   
                                }
                            }
                            using (StreamWriter sw = new StreamWriter(rutaFicheroClientes))
                            {
                                foreach (ClientesDto cli in listaClientes)
                                {

                                    sw.WriteLine(cli.IdCliente + ";" + cli.NombreCompletoCliente + ";" + cli.FchaNacimientoCliente
                                        + ";" + cli.DniNumCliente + ";" + cli.LetraCliente + ";" + cli.CorreoCliente);

                                }
                            }
                            cerrarMenu = true;
                            break;
                        case 1:
                            bi.crearBiblioteca();
                            break;
                        case 2:
                            mi.opcionMenuBiblioteca();
                            break;

                    }
                }
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }






}
    }      
}
