﻿using Biblioteca.Dtos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteca.Servicios
{
    internal  class BibliotecaImplementacion : BibliotecaInterfaz
    {
        public void crearBiblioteca()
        {
            Console.WriteLine("-----------------");
            Console.WriteLine("DAR ALTA BIBLIOTECA");
            Console.WriteLine("------------------------");
            long id = Utilidades.util.calcularIdBiblioteca();
            Console.WriteLine("Introduce el nombre de la biblioteca");
            string nombre = Console.ReadLine();
            Console.WriteLine("Introduce la direccion de la biblioteca ");
            string biblioteca = Console.ReadLine();
            BibliotecasDto bibli = new BibliotecasDto(id, nombre, biblioteca);
            Program.listaBiblioteca.Add(bibli);
        }
    }
}
