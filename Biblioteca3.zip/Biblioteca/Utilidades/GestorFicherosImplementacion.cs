﻿using Biblioteca.Dtos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteca.Utilidades
{
    internal class GestorFicherosImplementacion
    {
        
         public static void accesoAFicheros(string rutaFicheroGeneral)
         {
             if (File.Exists(rutaFicheroGeneral))
             {
                 string[] contenidoFichero = File.ReadAllLines(rutaFicheroGeneral);
                 foreach (string fichero in contenidoFichero)
                 {
                     // Dentro del bucle, se divide cada línea en partes usando el carácter ';' como separador.
                     string[] lineasContenido = fichero.Split(";");

                     BibliotecasDto biblioteca1 = new BibliotecasDto(long.Parse(lineasContenido[0]), lineasContenido[1], lineasContenido[2]);
                     Program.listaBiblioteca.Add(biblioteca1);
                 }
                 string[] arregloBibliotecas = File.ReadAllLines(rutaFicheroGeneral);
                 Console.WriteLine("Lista de bibliotecas habilitadas");
                 foreach (string line in arregloBibliotecas)
                 {
                     Console.WriteLine(line);
                 }

             }
              else
                 {
                     Console.WriteLine("No existen bibliotecas habilitadas");
                 }
         }
        public static void guardarClienteBDD(string rutaFicheroClientes)
        {
            if (File.Exists(rutaFicheroClientes))
            {
                string[] contenidoFichero = File.ReadAllLines(rutaFicheroClientes);
                foreach (string contenido in contenidoFichero)
                {
                    string[] partesDeLaLineas = contenido.Split(';');
                    ClientesDto client2 = new ClientesDto(Int64.Parse(partesDeLaLineas[0]), partesDeLaLineas[1], DateTime.Parse(partesDeLaLineas[2]), Int32.Parse(partesDeLaLineas[3]), Char.Parse( partesDeLaLineas[4]),(partesDeLaLineas[5]));
                    Program.listaClientes.Add(client2);
                }
            }
            else
            {
                Console.WriteLine("No hay ningun cliente disponible");
            }
        }

        /*
        
        public static void mostrarContenidoFicheros(string rutaFicheroGeneral)
        {
            if (File.Exists(rutaFicheroGeneral))
            {
                string[] contenidoFichero = File.ReadAllLines(rutaFicheroGeneral);
                Console.WriteLine("Contenido del archivo:");
                foreach (string linea in contenidoFichero)
                {
                    Console.WriteLine(linea);
                }
            }
            else
            {
                Console.WriteLine("Aun no existen bibliotecas habilitadas.");
            }

        }
        */
    }
}
