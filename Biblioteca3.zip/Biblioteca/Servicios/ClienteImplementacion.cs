﻿using Biblioteca.Dtos;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteca.Servicios
{
    internal class ClienteImplementacion : ClienteInterfaz
    {   
        public void validarAltaCliente()
        {
            Console.WriteLine("Introduzca el id de la biblioteca en la cual desea dar de alta al cliente");
            Utilidades.util.mostrarListaBibliotecas();
            long idBibliotecaSeleccionado = Convert.ToInt64(Console.ReadLine());
            foreach (BibliotecasDto biblio in Program.listaBiblioteca)
            {
                if (biblio.IdBiblioteca.Equals(idBibliotecaSeleccionado))
                {
                    darAltaCliente();
                }
                else
                {
                    Console.WriteLine("La biblioteca seleccionada no existe, introduzca un id valido");
                }
            }

        }


        private void darAltaCliente()
        {
            Console.WriteLine("-----------------");
            Console.WriteLine("DAR ALTA CLIENTE");
            Console.WriteLine("------------------------");
            long idU = Utilidades.util.calcularIdCliente();
            Console.WriteLine("Introduzca el nombre compreto del usuario");
            string usuario = Console.ReadLine();
            Console.WriteLine("Introduzca su fecha de nacimiento yyyy-mm-dd ");
            DateTime fchaNaciCliente = Convert.ToDateTime(Console.ReadLine());
            Console.WriteLine("Introduzca los numeros del DNI");
            int numerodni=Convert.ToInt32 (Console.ReadLine());
            Console.WriteLine("Introduzca la letra del dni");
            char letra= Convert.ToChar(Console.ReadLine().ToUpper());
            var dniCl = verificarDni(numerodni, letra);
            Console.WriteLine("Introduzca el correo del usuario");
            string correo = Console.ReadLine(); 
            ClientesDto cliente = new ClientesDto(idU,
                        usuario, fchaNaciCliente, numerodni, letra, correo);
            Program.listaClientes.Add(cliente);
        }

        private int verificarDni(int dniCliente, char letraCliente)

        {
            int dniVerificar = -1;
            char letra = ' ';

            int[] resto = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22 };
            char[] letras = { 'T', 'R', 'W', 'A', 'G', 'M', 'Y', 'F', 'P', 'D', 'X', 'B', 'N', 'J', 'Z', 'S', 'Q', 'V', 'H', 'L', 'C', 'K', 'E' };

            int divisor = 23;
            int operacion = dniCliente % divisor;

            int posicionResto = resto[operacion];

            if (letraCliente == letras[posicionResto])
            {

                Console.WriteLine("DNI válido");
                dniVerificar = dniCliente; // Asigna el DNI verificado a la variable de retorno
            }
            else
            {
                Console.WriteLine("La letra ingresada no coincide con la letra calculada.");
            }
            return dniVerificar;
        }
    }
}
