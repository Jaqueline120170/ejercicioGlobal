﻿using Biblioteca.Dtos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteca.Servicios
{
    internal class MenuImplementacion : MenuInterfaz
    {
        ClienteInterfaz ci = new ClienteImplementacion();
        LibroInterfaz li = new LibroImplementacion();
        PrestamoInterfaz pi = new PrestamoImplementacion();

        public int mostrarMenuPrincipal()
        {
            int opcionMenuPrincipal;
            Console.WriteLine("---------------------");
            Console.WriteLine("0. Cerrar Menu");
            Console.WriteLine("1. Crear biblioteca");
            Console.WriteLine("2. Acceder a menu biblioteca");
            Console.WriteLine("Seleccione una opcion");
            Console.WriteLine("------------------------");
            opcionMenuPrincipal=Convert.ToInt32(Console.ReadLine());
            return opcionMenuPrincipal;
        }
        private int menuBiblioteca()
        {
            int opcionMenuBiblioteca;
            Console.WriteLine("------------------------");
            Console.WriteLine("0. Volver al inicio");
            Console.WriteLine("1. Dar alta cliente");
            Console.WriteLine("2. Dar alta un libro");
            Console.WriteLine("3. Gestionar un prestamo");
            Console.WriteLine("Seleccione una opcion");
            Console.WriteLine("---------------------------");
            opcionMenuBiblioteca=Convert.ToInt32(Console.ReadLine());
            return opcionMenuBiblioteca;
        }
        public void opcionMenuBiblioteca()
        {
            int opcion = menuBiblioteca();

            switch (opcion)
            {
                case 0:

                    break;
                case 1:
                    ci.validarAltaCliente();
                    break;
                case 2:
                    li.validarAltaLibro();
                    break;
                case 3:
                    pi.validarAltaPrestamo();
                    break;
                case 4:
                    // oi.gestionarPrestamo();
                    break;
                default:
                    Console.WriteLine("Introduzca una opcion alida");
                    break;
            }
        }
    }
}
