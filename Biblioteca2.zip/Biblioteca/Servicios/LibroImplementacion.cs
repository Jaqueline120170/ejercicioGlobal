﻿using Biblioteca.Dtos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteca.Servicios
{
    internal class LibroImplementacion : LibroInterfaz
    {
        public void validarAltaLibro()
        {
           
            
                Console.WriteLine("Introduzca el id de la biblioteca en la cual desea dar de alta al LIBRO");
                Utilidades.util.mostrarListaBibliotecas();
                long idBibliotecaSeleccionado = Convert.ToInt64(Console.ReadLine());
                foreach (BibliotecasDto biblio in Program.listaBiblioteca)
                {
                    if (biblio.IdBiblioteca==idBibliotecaSeleccionado)
                    {
                        darAltaLibro();
                    }
                    else
                    {
                        Console.WriteLine("La biblioteca seleccionada no existe, introduzca un id valido");
                    }
                }

            

        }
        private void darAltaLibro()
        {
            Console.WriteLine("-----------------");
            Console.WriteLine("DAR ALTA LIBRO");
            Console.WriteLine("------------------------");
            long idLibro = Utilidades.util.calcularIdLibro();
            Console.WriteLine("Introduzca el titulo del libro");
            string titulo = Console.ReadLine();
            Console.WriteLine("Introduzca subtitulo del libro");
            string subtitulo = Console.ReadLine();
            Console.WriteLine("Introduzca nombre del autor");
            string autor = Console.ReadLine();
            Console.WriteLine("Introduzca codigo ISBN del libro ");
            string codigo = Console.ReadLine();
            Console.WriteLine("Introduzca el numero de la edicion del libro");
            bool codigoDuplicado = verificarDuplicados(codigo);
            int numEdi = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Introduzca el stock del libro");
            int numStock =Convert.ToInt32( Console.ReadLine());
            LibrosDto libro= new LibrosDto(idLibro,titulo,subtitulo,autor,codigo,numEdi,numStock);
            Program.listaLibros.Add(libro);

            Console.WriteLine("-----------------------");
            Console.WriteLine("Libro agregado con exito");
            foreach(LibrosDto lib in Program.listaLibros)
            {
                Console.WriteLine(lib.ToString());

            }
        }
        private bool verificarDuplicados(string codigo)
        {
            foreach (LibrosDto libro in Program.listaLibros)
            {
                if (libro.CodigoISBN.Equals(codigo))
                {

                    Console.WriteLine("Se ha detectado un codigo ISBN duplicado, vuelva a intentar ");
                    return true;
                }
            }
            return false;
        }
    }
}
