﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteca.Dtos
{
    internal class LibrosDto
    {
         ///Propiedades del obejto librosDto
        long idLibro;
        string tituloLibro = "aaaaa";
        string subtituloLibro = "aaaaa";
        string autorLibro = "aaaaa";
        string codigoISBN = "aaaaa";
        int numeroEdicion = 11111;
        int stockLibros= 11111;


        ///Contructor vacío
        public LibrosDto()
        {
        }

        ///constructor de referencia
        public LibrosDto(long idLibro, string tituloLibro, string subtituloLibro, string autorLibro, string codigoISBN, int numeroEdicion, int stockLibros)
        {
            this.idLibro = idLibro;
            this.tituloLibro = tituloLibro;
            this.subtituloLibro = subtituloLibro;
            this.autorLibro = autorLibro;
            this.codigoISBN = codigoISBN;
            this.numeroEdicion = numeroEdicion;
            this.stockLibros = stockLibros;
        }

        public long IdLibro { get => idLibro; set => idLibro = value; }
        public string TituloLibro { get => tituloLibro; set => tituloLibro = value; }
        public string SubtituloLibro { get => subtituloLibro; set => subtituloLibro = value; }
        public string AutorLibro { get => autorLibro; set => autorLibro = value; }
        public string CodigoISBN { get => codigoISBN; set => codigoISBN = value; }
        public int NumeroEdicion { get => numeroEdicion; set => numeroEdicion = value; }
        public int StockLibros { get => stockLibros; set => stockLibros = value; }

        override
        public string ToString()
        {
            string libroString = "Lista de libros\n" + this.idLibro + " " + this.tituloLibro;
            return libroString;
        }
    }
}
